$(document).ready(function() {

//variable declaration///
    let level = 1;
    let score = 0;
    let word; 
    let correct = 0;
    var norcorrect = false;
    var eightletter = [];
	
	//load disctionary file
    $.get('json/dictionary.txt', function(data) {
        eightletter = data.split('\n');
        //console.log(eightletter)

        var fourletterscramword = eightletter.filter(eightletter => eightletter.length >= 5 && eightletter.length <= 5);
        var fiveletterscramword = eightletter.filter(eightletter => eightletter.length >= 6 && eightletter.length <= 6);
        var sixletterscramword = eightletter.filter(eightletter => eightletter.length >= 7 && eightletter.length <= 7);
        var sevenletterscramword = eightletter.filter(eightletter => eightletter.length >= 8 && eightletter.length <= 8);
        var eightletterscramword = eightletter.filter(eightletter => eightletter.length >= 9 && eightletter.length <= 9);


		//reset letters
        function reset() {
            level = 1;
            score = 0;
            correct = 0; 
            word = "";
            updateBoard();
            $("#info").html('');

        }
		
		//random word //
        function randomWord(lvl) {
            word = lvl[Math.floor(Math.random() * lvl.length + 1) - 1];
            return word;
        }
		
		
		//scramble the dictionary words//
        function scrambleWord(word) {
            let letters = word.trim().split("");
            let currentIndex = letters.length,
                temporaryValue,
                randomIndex;


            while (0 !== currentIndex) {

                randomIndex = Math.floor(Math.random() * currentIndex);
                currentIndex -= 1;


                temporaryValue = letters[currentIndex];
                letters[currentIndex] = letters[randomIndex];
                letters[randomIndex] = temporaryValue;
            }
            $("#scrambled-word").empty();
            $("#scrambled-word-drop").empty();

            $.each(letters, function(i, v) {

                $("#scrambled-word-drop").append($("<span class='dropable' id='dropBox" + (i + 1) + "'>"));
                $("#scrambled-word").append($("<span class='dragable' id='dragBox" + (i + 1) + "'>").text(v));
                $("#dragBox" + (i + 1) + "").draggable({
                    revert: "invalid",
                    helper: "clone",
                    cursor: "move"
                });
                $(".dropable").droppable({
                    accept: ".dragable",
					 
                    drop: function(event, ui) {
						 
                        //console.log(string+":::"+$(".dropable .dragable").text());
                        /*i f(ui.draggable.text().length == 4){
						$("#val_txt").empty();
						$("#val_txt").append(finalstring); 
						} */
                        //console.log($(".dropable .dragable").text()); 
                        $(this)
                            .append(ui.draggable.css({
                                position: 'relative',
                                left: '5px',
                                top: '0px',
                            }))

					 
                    }
					
                });
            });

           
        }
		
		
		//level and score update
        function updateBoard() {
            $("#score").html(score);
            $("#level").html(level); 
        }
		
		
		//validation 
        function checkAnswer(guess) {
            // console.log(typeof guess+"::"+typeof word);
            // console.log(guess+"::"+word);
            var str1 = guess.trim();
            var str2 = word.trim();


            if (str1 == str2) {
                correct += 1;
                $("#info").html("<span class='correct'>CORRECT</span>");
                if (level == 1) {
                    score += 5;
                } else if (level == 2) {
                    score += 10;
                } else if (level == 3) {
                    score += 15;
                } else if (level == 4) {
                    score += 20;
                } else if (level == 5) {
                    score += 25;
                }
                norcorrect = false;
            } else {
                norcorrect = true;
                $("#info").html("<span class='incorrect'>That's not right!</span>");
 
            }
            if (correct == 2) {
                level += 1;
                correct = 0;
            }
            setLevel();
            updateBoard();
        }
		
		
		//levels setup  
        function setLevel() {

            if (level == 1) {
                if (norcorrect == true) {
                    norcorrect = false;
                } else if (norcorrect == false) {
                    randomWord(fourletterscramword);
                }
            } else if (level == 2) {
                if (norcorrect == true) {
                    norcorrect = false;
                } else if (norcorrect == false) {
                    randomWord(fiveletterscramword);
                }

            } else if (level == 3) {
                if (norcorrect == true) {
                    norcorrect = false;
                } else if (norcorrect == false) {
                    randomWord(sixletterscramword);
                }

            } else if (level == 4) {
                if (norcorrect == true) {
                    norcorrect = false;
                } else if (norcorrect == false) {
                    randomWord(sevenletterscramword);
                }
            } else if (level == 5) {
                if (norcorrect == true) {
                    norcorrect = false;
                } else if (norcorrect == false) {
                    randomWord(eightletterscramword);
                }
            } else if (level == 6) {
                $("#submit").off();
                $("#submit").css('opacity', '0.5');
                $("#submit").css('pointer-events', 'none');
                $("#reset-btn").css('pointer-events', 'none');
                $("#reset-btn").css('opacity', '0.5');
                $("#reset-btn").off();
                $("#info").html("<span class='win'>You win!  you have completed all the levels.</span>");
            }

            // console.log(`Word: ${word}`);
            $("#scrambled-word").html(scrambleWord(word));
        }
		
		//play button 
        $("#play-btn").on("click", function(e) {
            $("#rules").hide();
            $("#game-container").show();
            setLevel();
        });
		
		
		//submit button for validation
        $("#submit").on("click", function(e) {
            console.log($("#val_txt").text())
            $("#val_txt").empty();
            var string = $(".dropable .dragable").text();
            $("#val_txt").append(string);
            console.log(level)
            if (level == 1) {
                if (string.length == 4) {
                    checkAnswer(string)
                }

            } else if (level == 2) {
                if (string.length == 5) {
                    checkAnswer(string)
                }
            } else if (level == 3) {
                if (string.length == 6) {
                    checkAnswer(string)
                }
            } else if (level == 4) {
                if (string.length == 7) {
                    checkAnswer(string)
                }
            } else if (level == 5) {
                if (string.length == 8) {
                    checkAnswer(string)
                }
            }
        });
		
		//reset button
        $("#reset-btn").on("click", function(e) {
            reset();
            setLevel();
            $("#guess-container").show();
            $("#user-guess").val('');
        });

        //setLevel();


    });

});